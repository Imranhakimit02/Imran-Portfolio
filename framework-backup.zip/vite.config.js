import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { resolve } from 'node:path';

export default defineConfig({
  root: 'frontend',
  base: './',
  publicDir: 'public',
  plugins: [react(), tailwindcss()],
  build: {
    outDir: '../dist',
    emptyOutDir: true,
    assetsDir: 'build-assets',
    rollupOptions: {
      input: Object.fromEntries(['index', 'project', 'certs', 'resume', 'contact'].map(page => [page, resolve(import.meta.dirname, 'frontend', `${page}.html`)])),
    },
  },
});
