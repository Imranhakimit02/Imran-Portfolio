import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { writeFileSync, readFileSync } from 'node:fs';
import { Header, Footer } from '../frontend/src/components.jsx';
import { Overview, Projects, Awards, Contact } from '../frontend/src/Pages.jsx';
import { Resume } from '../frontend/src/Resume.jsx';
import { projects } from '../frontend/src/data.js';
const pages = { index: [Overview, 'Overview'], project: [Projects, 'Projects'], certs: [Awards, 'Awards & learning'], contact: [Contact, 'Contact'], resume: [Resume, 'Résumé'] };
for (const [name, [Page, title]] of Object.entries(pages)) {
 let content = renderToStaticMarkup(<><a className="skip" href="#main">Skip to content</a><Header page={name}/><main id="main"><Page/></main><Footer/></>);
 content = content.replace('grid grid-cols-1 gap-6 min-[701px]:grid-cols-2', 'projects').replace('wrap flex flex-wrap items-center justify-between gap-5', 'wrap');
 if (name === 'resume') content = content.replace('</main>', '<div class="wrap resume-pdf" id="resume-pdf" hidden><p>This is the original PDF. <a href="assets/Imran-Hakim-Resume.pdf" target="_blank" rel="noopener noreferrer">Open it directly</a> if the preview is unavailable.</p><iframe data-src="assets/Imran-Hakim-Resume.pdf#view=FitH" title="Muhammad Imran Hakim original PDF résumé"></iframe></div></main>');
 if (name === 'project') content += projects.map(project => renderToStaticMarkup(<dialog id={'case-'+project.id} aria-labelledby={'title-'+project.id}><div className="dialog-top"><span>Project case study</span><button className="close-case">Close ×</button></div><h2 id={'title-'+project.id}>{project.name}</h2><p className="tags">{project.org} / {project.tech}</p><p>{project.intro}</p><h3>The challenge</h3><p>{project.challenge}</p><h3>What I built</h3><ul>{project.built.map(item=><li key={item}>{item}</li>)}</ul><h3>The result</h3><p>{project.result}</p></dialog>)).join('');
 writeFileSync(name+'.html', '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<meta name="description" content="Muhammad Imran Hakim: IT support, infrastructure and application development portfolio.">\n<title>'+title+' | Imran Hakim</title>\n<link rel="stylesheet" href="styles.css">\n<script src="app.js" defer></script>\n</head>\n<body>\n'+content.replace(/></g,'>\n<')+'\n</body>\n</html>\n');
}
let css=readFileSync('frontend/src/styles.css','utf8').replace(/^@import "tailwindcss";\s*/,'').replace(/^@source .*?;\s*/m,'');
css+='\n[hidden]{display:none!important}.close-case{border:0;background:transparent;padding:8px}#resume-pdf{margin-bottom:80px}.resume-sidebar nav{min-height:0}\n';
writeFileSync('styles.css',css);
console.log('Exported five standalone HTML pages and plain CSS.');
