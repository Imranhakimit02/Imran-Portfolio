import { copyFile, cp, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';

// Copy only this application's build outputs; leave source and user assets intact.
const root = resolve(import.meta.dirname, '..');
for (const page of ['index.html', 'project.html', 'certs.html', 'resume.html', 'contact.html']) {
  await copyFile(resolve(root, 'dist', page), resolve(root, page));
}
await mkdir(resolve(root, 'build-assets'), { recursive: true });
await cp(resolve(root, 'dist/build-assets'), resolve(root, 'build-assets'), { recursive: true });
await mkdir(resolve(root, 'assets'), { recursive: true });
await copyFile(resolve(root, 'dist/assets/Imran-Hakim-Resume.pdf'), resolve(root, 'assets/Imran-Hakim-Resume.pdf'));
console.log('Updated XAMPP portfolio: http://localhost/my_portfolio/');
