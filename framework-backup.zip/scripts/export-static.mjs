// scripts/export-static.jsx
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { writeFileSync, readFileSync } from "node:fs";

// frontend/src/components.jsx
import { Fragment, useEffect, useRef, useState } from "react";

// frontend/src/data.js
var projects = [
  { id: "flowdesk", name: "FlowDesk", category: "enterprise", org: "Leader Energy", tech: "PHP / MySQL / JavaScript", intro: "Dynamic requests and multi-tier approvals for HR and Finance workflows.", steps: ["Request", "Approve", "Resolve"], caption: "One request. A clear path forward.", challenge: "Department-specific inputs and multiple approval tiers need a flexible process.", built: ["Designed relational schemas and ERDs for configurable approval workflows.", "Built dynamic JavaScript forms backed by JSON metadata for category-specific inputs.", "Implemented uploads, request priorities, multi-tier routing, and secure token tracking."], result: "Centralized employee submissions and tracking, with flexible workflows that adapt to departmental requirements." },
  { id: "process", name: "ProcessFlow", category: "enterprise", org: "Leader Energy", tech: "PHP / MySQL / RBAC", intro: "Project coordination, approval handoffs, and visibility across nine departments.", steps: ["Submit", "Coordinate", "Track"], caption: "Connected across nine departments.", challenge: "Project requests, approvals, ownership, and progress need to remain visible across departmental handoffs.", built: ["Structured requester, staff, and approver access with dynamic department and role mappings.", "Built HOD and C-Suite approval gateways, rejection paths, and centralized progress tracking.", "Implemented GCEO visibility, department chat, audit history, and date-based filters."], result: "A shared view of project responsibilities, approval status, and department progress." },
  { id: "ar", name: "AR MicroLearn", category: "academic", org: "UniSZA / Gold & Silver awards", tech: "Vuforia / Augmented reality", intro: "Physical flashcards bring 15+ microorganisms into interactive 3D learning.", challenge: "Microorganisms can be difficult to visualize through static learning materials alone.", built: ["Developed an AR educational application using Vuforia image tracking.", "Displayed interactive 3D models from physical flashcards.", "Aligned 15+ microorganisms with the Malaysian Year 6 KSSR Science syllabus."], result: "AR MicroLearn received a Gold Award at the UniSZA Final Year Project Showcase and a Silver Award at Minggu Penyelidikan & Inovasi (MPI) 2026. Both awards recognize the same degree final-year project." },
  { id: "gym", name: "Gym Management System", category: "academic", org: "UTeM / Diploma project", tech: "C# / .NET / SQL", intro: "Desktop registration and membership tracking with a relational SQL database.", challenge: "Membership administration requires consistent records and a straightforward registration process.", built: ["Built a C#/.NET desktop application supporting 100+ member records.", "Automated registration, record management, and membership tracking.", "Performed functional testing, debugging, and database validation in Visual Studio 2022."], result: "Combined member administration in a single application with checks on application behavior and record consistency." }
];
var weeks = [["Aug 10\u201314", "Orientation & foundations", "Completed onboarding, department orientation, and a review of ticketing and support procedures."], ["Aug 17\u201321", "Endpoint provisioning", "Re-imaged corporate laptops, configured Windows, handled BitLocker recovery, and troubleshot hardware."], ["Aug 24\u201328", "From requirements to databases", "Translated discussions into ERDs and relational schemas for department request tools."], ["Aug 31\u2013Sep 4", "Connecting forms to workflows", "Built PHP scripts linking form submissions with databases and approval routing."], ["Sep 7\u201311", "Physical network infrastructure", "Terminated Cat5e/Cat6 cables, wired patch panels, tested lines, and organized server racks."], ["Sep 14\u201318", "Keeping users connected", "Provided hardware and network support, maintenance, and cross-department ticket resolution."], ["Sep 21\u201325", "Testing data & access", "Tested PHP logic, SQL queries, integrity, permissions, and approval tracking."], ["Sep 28\u2013Oct 2", "A flexible form engine", "Implemented JSON metadata and dynamic JavaScript fields for HR, IT, and Finance requests without adding schema columns for every category."], ["Oct 5\u20139", "Modular approval routing", "Separated email verification from approvals, added configurable approval steps, reorganized HOD dashboards, and drafted BD flowcharts."], ["Oct 12\u201316", "Usability & token security", "Refined FlowDesk portals and administrative guidance, documented progress, and strengthened tracking tokens."], ["Oct 19\u201323", "Blueprinting ProcessFlow", "Prepared ERDs, workflow diagrams, and a data dictionary. Added GitHub version control, researched cloud security, and prototyped a Gemini AI mental health application."], ["Oct 26\u201330", "Multi-department workflow engine", "Implemented passwordless email verification, session logging, dynamic routing, mandatory approval gateways, rejection handling, and department tracking."], ["Nov 2\u20136", "Administration & collaboration", "The supplied log records unified login routing, shared approver logic, admin CRUD, project filtering, department chat, and an Entra ID versus Windows AD review. This week was ongoing when the portfolio was prepared."]];

// frontend/src/components.jsx
import { Fragment as Fragment2, jsx, jsxs } from "react/jsx-runtime";
function Journal() {
  return /* @__PURE__ */ jsx("div", { id: "journal", children: weeks.map(
    ([date, title, text], index) => /* @__PURE__ */ jsxs("details", { children: [
      /* @__PURE__ */ jsxs("summary", { children: [
        /* @__PURE__ */ jsxs("small", { children: [
          "Week ",
          index + 1,
          " / ",
          date
        ] }),
        /* @__PURE__ */ jsx("strong", { children: title })
      ] }),
      /* @__PURE__ */ jsx("p", { children: text })
    ] }, title)
  ) });
}
function CopyEmail() {
  const [status, setStatus] = useState("");
  async function copy() {
    try {
      await navigator.clipboard.writeText("imranhakimit02@gmail.com");
      setStatus("Email copied.");
    } catch {
      setStatus("Please copy: imranhakimit02@gmail.com");
    }
  }
  return /* @__PURE__ */ jsxs(Fragment2, { children: [
    /* @__PURE__ */ jsx("button", { id: "copy", onClick: copy, children: "Copy email address" }),
    /* @__PURE__ */ jsx("span", { id: "status", role: "status", children: status })
  ] });
}
function CaseStudy({ project, onClose }) {
  const dialog = useRef(null);
  useEffect(() => {
    const node = dialog.current;
    node.showModal();
    return () => node.close();
  }, []);
  function dismissBackdrop(event) {
    if (event.target !== dialog.current) return;
    const box = dialog.current.getBoundingClientRect();
    if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) onClose();
  }
  return /* @__PURE__ */ jsxs("dialog", { ref: dialog, id: "case", "aria-labelledby": "case-title", onCancel: (event) => {
    event.preventDefault();
    onClose();
  }, onClick: dismissBackdrop, children: [
    /* @__PURE__ */ jsxs("div", { className: "dialog-top", children: [
      /* @__PURE__ */ jsx("span", { children: "Project case study" }),
      /* @__PURE__ */ jsxs("button", { id: "close", onClick: onClose, children: [
        "Close ",
        /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\xD7" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("h2", { id: "case-title", children: project.name }),
    /* @__PURE__ */ jsxs("p", { className: "tags", children: [
      project.org,
      " / ",
      project.tech
    ] }),
    /* @__PURE__ */ jsx("p", { children: project.intro }),
    /* @__PURE__ */ jsx("h3", { children: "The challenge" }),
    /* @__PURE__ */ jsx("p", { children: project.challenge }),
    /* @__PURE__ */ jsx("h3", { children: "What I built" }),
    /* @__PURE__ */ jsx("ul", { children: project.built.map((item) => /* @__PURE__ */ jsx("li", { children: item }, item)) }),
    /* @__PURE__ */ jsx("h3", { children: "The result" }),
    /* @__PURE__ */ jsx("p", { children: project.result })
  ] });
}
function ProjectGallery() {
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState(null);
  const trigger = useRef(null);
  function close() {
    setSelected(null);
    trigger.current?.focus();
  }
  const filters = [["all", "All projects"], ["enterprise", "Enterprise applications"], ["academic", "Academic projects"]];
  return /* @__PURE__ */ jsxs(Fragment2, { children: [
    /* @__PURE__ */ jsx("div", { className: "filters", role: "group", "aria-label": "Filter projects", children: filters.map(([value, label]) => /* @__PURE__ */ jsx("button", { "data-filter": value, "aria-pressed": filter === value, onClick: () => setFilter(value), children: label }, value)) }),
    /* @__PURE__ */ jsx("div", { id: "projects", className: "grid grid-cols-1 gap-6 min-[701px]:grid-cols-2", children: projects.filter((project) => filter === "all" || project.category === filter).map(
      (project) => /* @__PURE__ */ jsxs("article", { className: "project", "data-category": project.category, children: [
        project.steps && /* @__PURE__ */ jsxs("div", { className: "art " + project.id, "aria-hidden": "true", children: [
          /* @__PURE__ */ jsx("span", { className: "art-title", children: project.name }),
          /* @__PURE__ */ jsx("div", { className: "route", children: project.steps.map((step, index) => /* @__PURE__ */ jsxs(Fragment, { children: [
            index > 0 && "\u2192",
            /* @__PURE__ */ jsx("span", { children: step })
          ] }, step)) }),
          /* @__PURE__ */ jsx("span", { className: "art-foot", children: project.caption })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "body", children: [
          /* @__PURE__ */ jsxs("div", { className: "meta", children: [
            /* @__PURE__ */ jsx("span", { children: project.org }),
            /* @__PURE__ */ jsxs("span", { children: [
              "0",
              projects.indexOf(project) + 1,
              " / ",
              project.category === "enterprise" ? "Enterprise" : "Academic"
            ] })
          ] }),
          /* @__PURE__ */ jsx("h3", { children: project.name }),
          /* @__PURE__ */ jsx("p", { children: project.intro }),
          /* @__PURE__ */ jsxs("div", { className: "project-bottom", children: [
            /* @__PURE__ */ jsx("span", { children: project.tech }),
            /* @__PURE__ */ jsx("button", { className: "open", "data-project": project.id, "aria-label": "Read " + project.name + " case study", onClick: (event) => {
              trigger.current = event.currentTarget;
              setSelected(project);
            }, children: "View case study \u2197" })
          ] })
        ] })
      ] }, project.id)
    ) }),
    selected && /* @__PURE__ */ jsx(CaseStudy, { project: selected, onClose: close })
  ] });
}
function Header({ page }) {
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(() => {
    try {
      return localStorage.getItem("portfolio-theme") === "dark";
    } catch {
      return false;
    }
  });
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    try {
      localStorage.setItem("portfolio-theme", dark ? "dark" : "light");
    } catch {
    }
  }, [dark]);
  useEffect(() => {
    function escape(event) {
      if (event.key === "Escape") setOpen(false);
    }
    document.addEventListener("keydown", escape);
    return () => document.removeEventListener("keydown", escape);
  }, []);
  const links = [["index", "Overview"], ["project", "Projects"], ["certs", "Awards & learning"], ["resume", "R\xE9sum\xE9"], ["contact", "Contact"]];
  return /* @__PURE__ */ jsx("header", { children: /* @__PURE__ */ jsxs("nav", { className: "wrap", "aria-label": "Main navigation", children: [
    /* @__PURE__ */ jsxs("a", { className: "brand", href: "index.html", "aria-label": "Imran Hakim home", children: [
      "IH",
      /* @__PURE__ */ jsx("span", { className: "brand-name", children: "Imran Hakim" })
    ] }),
    /* @__PURE__ */ jsx("button", { id: "menu", "aria-expanded": open, "aria-controls": "links", onClick: () => setOpen((value) => !value), children: "Menu" }),
    /* @__PURE__ */ jsxs("div", { id: "links", className: open ? "is-open" : "", children: [
      links.map(([id, label]) => /* @__PURE__ */ jsx("a", { href: id + ".html", "aria-current": id === page ? "page" : void 0, onClick: () => setOpen(false), children: label }, id)),
      /* @__PURE__ */ jsx("button", { id: "theme-toggle", "aria-label": "Switch colour theme", "aria-pressed": dark, onClick: () => setDark((value) => !value), children: dark ? "Light mode" : "Dark mode" }),
      /* @__PURE__ */ jsxs("a", { className: "resume", href: "assets/Imran-Hakim-Resume.pdf", download: true, children: [
        "Resume PDF ",
        /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\u2193" })
      ] })
    ] })
  ] }) });
}
function Footer() {
  return /* @__PURE__ */ jsxs("footer", { className: "wrap flex flex-wrap items-center justify-between gap-5", children: [
    /* @__PURE__ */ jsx("span", { children: "\xA9 2026 Imran Hakim / Malaysia" }),
    /* @__PURE__ */ jsx("a", { href: "contact.html", children: "Let's connect" }),
    /* @__PURE__ */ jsx("a", { href: "#main", children: "Back to top \u2191" })
  ] });
}

// frontend/src/Pages.jsx
import { Fragment as Fragment3, jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
function Overview() {
  return /* @__PURE__ */ jsxs2(Fragment3, { children: [
    /* @__PURE__ */ jsxs2("section", { className: "hero wrap", id: "home", children: [
      /* @__PURE__ */ jsx2("div", { className: "location", children: "Kota Bharu, Kelantan / Malaysia" }),
      /* @__PURE__ */ jsxs2("h1", { children: [
        "IMRAN",
        /* @__PURE__ */ jsx2("br", {}),
        "HAKIM",
        /* @__PURE__ */ jsx2("span", { className: "hero-period", children: "." })
      ] }),
      /* @__PURE__ */ jsxs2("p", { className: "hero-statement", children: [
        "IT support and application development.",
        /* @__PURE__ */ jsx2("br", {}),
        "Making technology work better for people."
      ] }),
      /* @__PURE__ */ jsxs2("div", { className: "actions", children: [
        /* @__PURE__ */ jsxs2("a", { className: "button", href: "project.html", children: [
          "Explore my work ",
          /* @__PURE__ */ jsx2("span", { "aria-hidden": "true", children: "\u2197" })
        ] }),
        /* @__PURE__ */ jsxs2("a", { className: "secondary", href: "contact.html", children: [
          "Get in touch ",
          /* @__PURE__ */ jsx2("span", { "aria-hidden": "true", children: "\u2192" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs2("div", { className: "hero-foot", children: [
        /* @__PURE__ */ jsx2("span", { children: "Final-year IT student at UniSZA" }),
        /* @__PURE__ */ jsx2("span", { children: "Currently interning at Leader Energy" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs2("section", { className: "wrap section split about", id: "about", children: [
      /* @__PURE__ */ jsxs2("div", { children: [
        /* @__PURE__ */ jsxs2("h2", { children: [
          "Curious by nature.",
          /* @__PURE__ */ jsx2("br", {}),
          "Practical by training."
        ] }),
        /* @__PURE__ */ jsx2("p", { children: "I\u2019m Muhammad Imran Hakim bin Abd Rashid, a final-year IT student from Kota Bharu, Kelantan. I enjoy working where people, technology, and everyday problem-solving meet." }),
        /* @__PURE__ */ jsx2("p", { children: "My interests span IT infrastructure, systems, and application support." })
      ] }),
      /* @__PURE__ */ jsxs2("div", { className: "education", children: [
        /* @__PURE__ */ jsxs2("article", { children: [
          /* @__PURE__ */ jsx2("small", { children: "2023 to 2027 (expected)" }),
          /* @__PURE__ */ jsx2("h3", { children: "Bachelor of Information Technology" }),
          /* @__PURE__ */ jsx2("p", { children: "Informatics Media / UniSZA" }),
          /* @__PURE__ */ jsx2("strong", { children: "3.68 CGPA" }),
          /* @__PURE__ */ jsx2("p", { children: "Dean\u2019s List: semesters 1, 3, 4, 5, 6" })
        ] }),
        /* @__PURE__ */ jsxs2("article", { children: [
          /* @__PURE__ */ jsx2("small", { children: "2020 to 2023" }),
          /* @__PURE__ */ jsx2("h3", { children: "Diploma in Information Technology" }),
          /* @__PURE__ */ jsx2("p", { children: "UTeM / 3.42 CGPA" })
        ] }),
        /* @__PURE__ */ jsx2("a", { className: "inline-link", href: "certs.html", children: "Awards & professional learning \u2192" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs2("section", { className: "wrap section", id: "skills", children: [
      /* @__PURE__ */ jsxs2("div", { className: "heading", children: [
        /* @__PURE__ */ jsx2("h2", { children: "A practical toolkit." }),
        /* @__PURE__ */ jsxs2("p", { children: [
          "Across devices, networks, applications,",
          /* @__PURE__ */ jsx2("br", {}),
          "and the data that connects them."
        ] })
      ] }),
      /* @__PURE__ */ jsxs2("div", { className: "skills", children: [
        /* @__PURE__ */ jsxs2("article", { children: [
          /* @__PURE__ */ jsx2("h3", { children: "IT support & endpoints" }),
          /* @__PURE__ */ jsx2("p", { children: "Windows 10/11 imaging, BitLocker, BIOS configuration, hardware troubleshooting, Microsoft 365, asset preparation and sanitization" })
        ] }),
        /* @__PURE__ */ jsxs2("article", { children: [
          /* @__PURE__ */ jsx2("h3", { children: "Network infrastructure" }),
          /* @__PURE__ */ jsx2("p", { children: "Cat5e/Cat6, RJ45 termination, patch panels, cable testing and tracing, server racks" })
        ] }),
        /* @__PURE__ */ jsxs2("article", { children: [
          /* @__PURE__ */ jsx2("h3", { children: "Application development" }),
          /* @__PURE__ */ jsx2("p", { children: "PHP, PDO, MySQL, JavaScript, HTML, CSS, C#/.NET, SQL, relational database design, RBAC, system testing, GitHub" })
        ] }),
        /* @__PURE__ */ jsxs2("article", { children: [
          /* @__PURE__ */ jsx2("h3", { children: "Data & emerging tools" }),
          /* @__PURE__ */ jsx2("p", { children: "Power BI, DAX, data modeling, interactive dashboards, Vuforia AR, Adobe Acrobat sign workflows" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx2("section", { id: "experience", className: "dark section", children: /* @__PURE__ */ jsxs2("div", { className: "wrap split", children: [
      /* @__PURE__ */ jsxs2("div", { children: [
        /* @__PURE__ */ jsxs2("h2", { children: [
          "Hands-on.",
          /* @__PURE__ */ jsx2("br", {}),
          "Every layer."
        ] }),
        /* @__PURE__ */ jsxs2("p", { children: [
          "Supporting the everyday.",
          /* @__PURE__ */ jsx2("br", {}),
          "Building what comes next."
        ] }),
        /* @__PURE__ */ jsx2("a", { href: "#journey", children: "Explore my internship log \u2193" })
      ] }),
      /* @__PURE__ */ jsxs2("div", { className: "timeline", children: [
        /* @__PURE__ */ jsxs2("article", { children: [
          /* @__PURE__ */ jsx2("small", { children: "Aug 2026 to Mar 2027 (expected)" }),
          /* @__PURE__ */ jsx2("h3", { children: "IT Support Intern" }),
          /* @__PURE__ */ jsx2("p", { children: "Leader Energy Group Berhad / George Town" }),
          /* @__PURE__ */ jsx2("p", { children: "PHP business applications, Windows endpoint provisioning, user support, and server-room network infrastructure." })
        ] }),
        /* @__PURE__ */ jsxs2("article", { children: [
          /* @__PURE__ */ jsx2("small", { children: "Jun to Aug 2022" }),
          /* @__PURE__ */ jsx2("h3", { children: "IT Assistant Intern" }),
          /* @__PURE__ */ jsx2("p", { children: "Universiti Teknikal Malaysia Melaka" }),
          /* @__PURE__ */ jsx2("p", { children: "U-CREDs interface improvements for 300+ students and faculty, system testing, and data audits covering 100+ production assets." })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs2("section", { id: "journey", className: "wrap section journal-section", children: [
      /* @__PURE__ */ jsxs2("div", { className: "heading", children: [
        /* @__PURE__ */ jsx2("h2", { children: "Learning, put into practice." }),
        /* @__PURE__ */ jsxs2("p", { children: [
          "An internship journal.",
          /* @__PURE__ */ jsx2("br", {}),
          "August to November 2026."
        ] })
      ] }),
      /* @__PURE__ */ jsx2(Journal, {}),
      /* @__PURE__ */ jsxs2("details", { children: [
        /* @__PURE__ */ jsx2("summary", { children: "Additional technical milestones" }),
        /* @__PURE__ */ jsx2("p", { children: "Prepared 20+ returned units for HP asset return; configured multi-recipient Adobe Acrobat signature routing; researched Blue-Green deployments, cloud security, and IT compliance." })
      ] })
    ] }),
    /* @__PURE__ */ jsxs2("section", { className: "wrap section", children: [
      /* @__PURE__ */ jsx2("h2", { children: "See the systems behind the work." }),
      /* @__PURE__ */ jsx2("a", { className: "button", href: "project.html", children: "Explore all four projects \u2192" })
    ] })
  ] });
}
function Projects() {
  return /* @__PURE__ */ jsxs2(Fragment3, { children: [
    /* @__PURE__ */ jsxs2("section", { className: "page-intro wrap", children: [
      /* @__PURE__ */ jsx2("span", { className: "page-index", children: "01 / Selected work" }),
      /* @__PURE__ */ jsxs2("h1", { children: [
        "Systems with",
        /* @__PURE__ */ jsx2("br", {}),
        "a purpose."
      ] }),
      /* @__PURE__ */ jsx2("p", { children: "From enterprise workflows to interactive learning. Four projects, each solving a practical problem." })
    ] }),
    /* @__PURE__ */ jsxs2("section", { className: "wrap section", id: "work", children: [
      /* @__PURE__ */ jsxs2("div", { className: "heading", children: [
        /* @__PURE__ */ jsx2("h2", { children: "Built to make work flow." }),
        /* @__PURE__ */ jsxs2("p", { children: [
          "Business applications and academic projects.",
          /* @__PURE__ */ jsx2("br", {}),
          "Explore the thinking behind each build."
        ] })
      ] }),
      /* @__PURE__ */ jsx2(ProjectGallery, {}),
      /* @__PURE__ */ jsx2("p", { className: "note", children: "Workflow graphics illustrate system concepts. Internal application access and company records are private." })
    ] })
  ] });
}
function Awards() {
  return /* @__PURE__ */ jsxs2(Fragment3, { children: [
    /* @__PURE__ */ jsxs2("section", { className: "wrap page-intro", children: [
      /* @__PURE__ */ jsx2("span", { className: "page-index", children: "02 / Recognition & growth" }),
      /* @__PURE__ */ jsxs2("h1", { children: [
        "Always",
        /* @__PURE__ */ jsx2("br", {}),
        "learning."
      ] }),
      /* @__PURE__ */ jsx2("p", { children: "Academic recognition, professional training, and learning through practice." })
    ] }),
    /* @__PURE__ */ jsxs2("section", { className: "wrap section", children: [
      /* @__PURE__ */ jsx2("h2", { children: "Awards" }),
      /* @__PURE__ */ jsxs2("div", { className: "award-grid", children: [
        /* @__PURE__ */ jsxs2("article", { className: "award", children: [
          /* @__PURE__ */ jsx2("span", { className: "award-number", children: "01 / Gold" }),
          /* @__PURE__ */ jsx2("h3", { children: "Final Year Project Showcase" }),
          /* @__PURE__ */ jsx2("p", { children: "Universiti Sultan Zainal Abidin" }),
          /* @__PURE__ */ jsx2("p", { children: "AR MicroLearn, degree final-year project." })
        ] }),
        /* @__PURE__ */ jsxs2("article", { className: "award", children: [
          /* @__PURE__ */ jsx2("span", { className: "award-number", children: "02 / Silver" }),
          /* @__PURE__ */ jsx2("h3", { children: "Minggu Penyelidikan & Inovasi" }),
          /* @__PURE__ */ jsx2("p", { children: "MPI 2026" }),
          /* @__PURE__ */ jsx2("p", { children: "AR MicroLearn, the same degree final-year project presented at the UniSZA showcase." })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs2("section", { className: "wrap section", children: [
      /* @__PURE__ */ jsx2("h2", { children: "Professional learning" }),
      /* @__PURE__ */ jsxs2("details", { children: [
        /* @__PURE__ */ jsx2("summary", { children: "Power BI / HRD Corp, August 2025" }),
        /* @__PURE__ */ jsx2("p", { children: "Data modeling, DAX, and interactive dashboards." })
      ] }),
      /* @__PURE__ */ jsxs2("details", { children: [
        /* @__PURE__ */ jsx2("summary", { children: "Cloud security & deployment research" }),
        /* @__PURE__ */ jsx2("p", { children: "Independent research into IaaS/PaaS cloud security and Blue-Green deployment strategies." })
      ] }),
      /* @__PURE__ */ jsxs2("details", { children: [
        /* @__PURE__ */ jsx2("summary", { children: "Document workflow automation" }),
        /* @__PURE__ */ jsx2("p", { children: "Configured multi-recipient signature routing in Adobe Acrobat." })
      ] })
    ] })
  ] });
}
function Contact() {
  return /* @__PURE__ */ jsxs2(Fragment3, { children: [
    /* @__PURE__ */ jsxs2("section", { className: "wrap page-intro", children: [
      /* @__PURE__ */ jsx2("span", { className: "page-index", children: "03 / Get in touch" }),
      /* @__PURE__ */ jsxs2("h1", { children: [
        "Let's make",
        /* @__PURE__ */ jsx2("br", {}),
        "IT work."
      ] }),
      /* @__PURE__ */ jsx2("p", { children: "Interested in IT support, infrastructure, systems, and application support opportunities." })
    ] }),
    /* @__PURE__ */ jsx2("section", { className: "contact section", id: "contact", children: /* @__PURE__ */ jsxs2("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxs2("h2", { children: [
        "Let\u2019s build",
        /* @__PURE__ */ jsx2("br", {}),
        "something useful."
      ] }),
      /* @__PURE__ */ jsx2("p", { children: "For opportunities in IT support, infrastructure, and application development." }),
      /* @__PURE__ */ jsx2("a", { className: "email", href: "mailto:imranhakimit02@gmail.com", children: "imranhakimit02@gmail.com \u2197" }),
      /* @__PURE__ */ jsxs2("div", { className: "contact-links", children: [
        /* @__PURE__ */ jsx2("a", { href: "https://www.linkedin.com/in/imran-hakim-0b195a366/", target: "_blank", rel: "noopener noreferrer", children: "LinkedIn \u2197" }),
        /* @__PURE__ */ jsx2("a", { href: "tel:+601119809130", children: "+60 11-1980 9130" }),
        /* @__PURE__ */ jsx2(CopyEmail, {})
      ] })
    ] }) })
  ] });
}

// frontend/src/Resume.jsx
import { useState as useState2 } from "react";
import { Fragment as Fragment4, jsx as jsx3, jsxs as jsxs3 } from "react/jsx-runtime";
var pdf = "assets/Imran-Hakim-Resume.pdf";
var sections = [["profile", "Profile"], ["experience", "Experience"], ["education", "Education"], ["projects", "Projects"], ["skills", "Skills"], ["awards", "Awards"]];
var skills = [
  ["IT support", ["Windows 10/11 imaging", "Hardware & software troubleshooting", "Microsoft 365", "User access support", "Endpoint provisioning", "BIOS / boot configuration", "Driver installation"]],
  ["Networking", ["Structured cabling", "RJ45 termination", "Patch panels", "Network racks", "Cable testing & tracing", "Network troubleshooting"]],
  ["Development", ["PHP", "MySQL / SQL", "HTML / CSS", "C# / .NET", "Relational database design", "RBAC", "System testing", "Vuforia AR", "Visual Studio 2022"]],
  ["Data", ["Microsoft Power BI", "DAX", "Data modeling", "Interactive dashboards"]]
];
function Icon({ type = "document" }) {
  const paths = {
    document: /* @__PURE__ */ jsxs3(Fragment4, { children: [
      /* @__PURE__ */ jsx3("path", { d: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" }),
      /* @__PURE__ */ jsx3("path", { d: "M14 2v6h6M8 13h8M8 17h6" })
    ] }),
    work: /* @__PURE__ */ jsxs3(Fragment4, { children: [
      /* @__PURE__ */ jsx3("rect", { x: "3", y: "7", width: "18", height: "14", rx: "1" }),
      /* @__PURE__ */ jsx3("path", { d: "M8 7V3h8v4M3 12h18M10 12v3h4v-3" })
    ] }),
    education: /* @__PURE__ */ jsx3(Fragment4, { children: /* @__PURE__ */ jsx3("path", { d: "m2 9 10-6 10 6-10 6zM6 12v6c4 3 8 3 12 0v-6M22 9v8" }) }),
    projects: /* @__PURE__ */ jsx3(Fragment4, { children: /* @__PURE__ */ jsx3("path", { d: "m8 5-7 7 7 7M16 5l7 7-7 7M14 3l-4 18" }) }),
    skills: /* @__PURE__ */ jsx3(Fragment4, { children: /* @__PURE__ */ jsx3("path", { d: "m12 2 9 5v10l-9 5-9-5V7zM3 7l9 5 9-5M12 12v10" }) }),
    awards: /* @__PURE__ */ jsxs3(Fragment4, { children: [
      /* @__PURE__ */ jsx3("circle", { cx: "12", cy: "8", r: "6" }),
      /* @__PURE__ */ jsx3("path", { d: "m8 13-2 9 6-3 6 3-2-9" })
    ] })
  };
  return /* @__PURE__ */ jsx3("svg", { width: "22", height: "22", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", children: paths[type] || paths.document });
}
function Heading({ id, children, icon }) {
  return /* @__PURE__ */ jsxs3("h2", { id: "resume-" + id, className: "cv-heading", children: [
    /* @__PURE__ */ jsx3(Icon, { type: icon || id }),
    children
  ] });
}
function Resume() {
  const [view, setView] = useState2("web");
  const [compact, setCompact] = useState2(false);
  return /* @__PURE__ */ jsxs3(Fragment4, { children: [
    /* @__PURE__ */ jsxs3("section", { className: "wrap resume-intro", children: [
      /* @__PURE__ */ jsxs3("div", { children: [
        /* @__PURE__ */ jsx3("span", { className: "page-index", children: "R\xE9sum\xE9 / A closer look" }),
        /* @__PURE__ */ jsxs3("h1", { children: [
          "Experience,",
          /* @__PURE__ */ jsx3("br", {}),
          "at a glance."
        ] }),
        /* @__PURE__ */ jsx3("p", { children: "The people I support. The systems I build. The skills behind both." })
      ] }),
      /* @__PURE__ */ jsxs3("a", { className: "button", href: pdf, download: true, children: [
        /* @__PURE__ */ jsx3(Icon, {}),
        "Download PDF ",
        /* @__PURE__ */ jsx3("span", { "aria-hidden": "true", children: "\u2193" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs3("section", { className: "wrap resume-workspace", "aria-label": "Interactive r\xE9sum\xE9", children: [
      /* @__PURE__ */ jsxs3("div", { className: "resume-toolbar", children: [
        /* @__PURE__ */ jsxs3("div", { className: "resume-views", role: "group", "aria-label": "R\xE9sum\xE9 format", children: [
          /* @__PURE__ */ jsx3("button", { "aria-pressed": view === "web", onClick: () => setView("web"), children: "Interactive r\xE9sum\xE9" }),
          /* @__PURE__ */ jsx3("button", { "aria-pressed": view === "pdf", onClick: () => setView("pdf"), children: "Original PDF" })
        ] }),
        view === "web" ? /* @__PURE__ */ jsx3("button", { className: "resume-density", "aria-pressed": compact, onClick: () => setCompact((value) => !value), children: compact ? "Show full details" : "Show highlights" }) : /* @__PURE__ */ jsx3("a", { className: "resume-density", href: pdf, target: "_blank", rel: "noopener noreferrer", children: "Open PDF in new tab \u2197" })
      ] }),
      view === "pdf" ? /* @__PURE__ */ jsxs3("div", { className: "resume-pdf", children: [
        /* @__PURE__ */ jsxs3("p", { children: [
          "This is the original PDF. ",
          /* @__PURE__ */ jsx3("a", { href: pdf, target: "_blank", rel: "noopener noreferrer", children: "Open it directly" }),
          " if the preview is unavailable."
        ] }),
        /* @__PURE__ */ jsx3("iframe", { src: pdf + "#view=FitH", title: "Muhammad Imran Hakim original PDF r\xE9sum\xE9" })
      ] }) : /* @__PURE__ */ jsxs3("div", { className: "resume-layout", children: [
        /* @__PURE__ */ jsxs3("aside", { className: "resume-sidebar", children: [
          /* @__PURE__ */ jsx3("span", { className: "resume-sidebar-label", children: "On this r\xE9sum\xE9" }),
          /* @__PURE__ */ jsx3("nav", { "aria-label": "R\xE9sum\xE9 sections", children: sections.map(([id, name]) => /* @__PURE__ */ jsxs3("a", { href: "#resume-" + id, children: [
            name,
            /* @__PURE__ */ jsx3("span", { "aria-hidden": "true", children: "\u2197" })
          ] }, id)) }),
          /* @__PURE__ */ jsxs3("div", { className: "resume-sidebar-note", children: [
            /* @__PURE__ */ jsx3(Icon, {}),
            /* @__PURE__ */ jsxs3("p", { children: [
              "Prefer a document?",
              /* @__PURE__ */ jsx3("br", {}),
              /* @__PURE__ */ jsx3("a", { href: pdf, download: true, children: "Keep a PDF copy \u2193" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs3("article", { className: "resume-sheet" + (compact ? " is-compact" : ""), "aria-label": "Muhammad Imran Hakim r\xE9sum\xE9", children: [
          /* @__PURE__ */ jsxs3("div", { className: "cv-masthead", children: [
            /* @__PURE__ */ jsxs3("div", { className: "cv-logo", "aria-hidden": "true", children: [
              "ih",
              /* @__PURE__ */ jsx3("span", { children: "." })
            ] }),
            /* @__PURE__ */ jsxs3("div", { children: [
              /* @__PURE__ */ jsxs3("h2", { children: [
                "Muhammad Imran Hakim",
                /* @__PURE__ */ jsx3("span", { children: "bin Abd Rashid" })
              ] }),
              /* @__PURE__ */ jsx3("p", { children: "IT support / Infrastructure / Application development" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs3("div", { className: "cv-contact", children: [
            /* @__PURE__ */ jsx3("span", { children: "Kota Bharu, Kelantan, Malaysia" }),
            /* @__PURE__ */ jsx3("a", { href: "mailto:imranhakimit02@gmail.com", children: "imranhakimit02@gmail.com" }),
            /* @__PURE__ */ jsx3("a", { href: "tel:+601119809130", children: "+60 11-1980 9130" }),
            /* @__PURE__ */ jsx3("a", { href: "https://www.linkedin.com/in/imran-hakim-0b195a366/", target: "_blank", rel: "noopener noreferrer", children: "LinkedIn \u2197" })
          ] }),
          /* @__PURE__ */ jsxs3("section", { children: [
            /* @__PURE__ */ jsx3(Heading, { id: "profile", icon: "document", children: "Professional profile" }),
            /* @__PURE__ */ jsx3("p", { children: "Final-year Bachelor of Information Technology (Informatics Media) student with a 3.68 CGPA and hands-on enterprise experience in IT infrastructure, technical support, and full-stack web development. Experienced in structured network cabling, endpoint provisioning, Windows deployment, troubleshooting, PHP/MySQL development, and relational database design." }),
            /* @__PURE__ */ jsx3("p", { className: "cv-detail", children: "Developed internal business applications at Leader Energy, including a cross-departmental ticketing and workflow system and a project monitoring system. Interested in building a career in IT infrastructure, systems, or application support." })
          ] }),
          /* @__PURE__ */ jsxs3("section", { children: [
            /* @__PURE__ */ jsx3(Heading, { id: "experience", icon: "work", children: "Work experience" }),
            /* @__PURE__ */ jsxs3("div", { className: "cv-entry", children: [
              /* @__PURE__ */ jsxs3("div", { className: "cv-entry-top", children: [
                /* @__PURE__ */ jsxs3("div", { children: [
                  /* @__PURE__ */ jsx3("h3", { children: "IT Support Intern" }),
                  /* @__PURE__ */ jsx3("p", { children: "Leader Energy Group Berhad / George Town" })
                ] }),
                /* @__PURE__ */ jsxs3("span", { children: [
                  "Aug 2026 \u2013 Mar 2027",
                  /* @__PURE__ */ jsx3("br", {}),
                  /* @__PURE__ */ jsx3("small", { children: "Expected completion" })
                ] })
              ] }),
              /* @__PURE__ */ jsx3("p", { className: "cv-highlight", children: "Built two internal PHP/MySQL applications, alongside hands-on enterprise IT support." }),
              /* @__PURE__ */ jsxs3("ul", { className: "cv-detail", children: [
                /* @__PURE__ */ jsx3("li", { children: "Built and deployed a nine-department project monitoring system and a ticketing system centralizing HR and Finance requests." }),
                /* @__PURE__ */ jsx3("li", { children: "Prepared corporate endpoints through Windows 10/11 reimaging, BIOS/boot configuration, driver installation, and software setup." }),
                /* @__PURE__ */ jsx3("li", { children: "Resolved hardware, software, and access issues for internal users." }),
                /* @__PURE__ */ jsx3("li", { children: "Established and verified server-room network connections through RJ45 termination, patch-panel installation, cable testing, and tracing." })
              ] })
            ] }),
            /* @__PURE__ */ jsxs3("div", { className: "cv-entry", children: [
              /* @__PURE__ */ jsxs3("div", { className: "cv-entry-top", children: [
                /* @__PURE__ */ jsxs3("div", { children: [
                  /* @__PURE__ */ jsx3("h3", { children: "IT Assistant Intern" }),
                  /* @__PURE__ */ jsx3("p", { children: "Universiti Teknikal Malaysia Melaka / Melaka" })
                ] }),
                /* @__PURE__ */ jsx3("span", { children: "Jun \u2013 Aug 2022" })
              ] }),
              /* @__PURE__ */ jsx3("p", { className: "cv-highlight", children: "Improved learning-system usability and tested data and application reliability." }),
              /* @__PURE__ */ jsxs3("ul", { className: "cv-detail", children: [
                /* @__PURE__ */ jsx3("li", { children: "Implemented U-CREDs interface improvements supporting access to learning resources for 300+ students and faculty." }),
                /* @__PURE__ */ jsx3("li", { children: "Identified defects and data inconsistencies through system testing and audits covering 100+ production assets." })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs3("section", { children: [
            /* @__PURE__ */ jsx3(Heading, { id: "education", children: "Education" }),
            /* @__PURE__ */ jsxs3("div", { className: "cv-entry", children: [
              /* @__PURE__ */ jsxs3("div", { className: "cv-entry-top", children: [
                /* @__PURE__ */ jsxs3("div", { children: [
                  /* @__PURE__ */ jsx3("h3", { children: "Bachelor of Information Technology" }),
                  /* @__PURE__ */ jsx3("p", { children: "Informatics Media / Universiti Sultan Zainal Abidin" })
                ] }),
                /* @__PURE__ */ jsxs3("span", { children: [
                  "2023 \u2013 2027",
                  /* @__PURE__ */ jsx3("br", {}),
                  /* @__PURE__ */ jsx3("small", { children: "Expected graduation" })
                ] })
              ] }),
              /* @__PURE__ */ jsxs3("div", { className: "cv-academic", children: [
                /* @__PURE__ */ jsx3("strong", { children: "3.68 CGPA" }),
                /* @__PURE__ */ jsx3("span", { children: "Dean\u2019s List: semesters 1, 3, 4, 5, 6" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs3("div", { className: "cv-entry", children: [
              /* @__PURE__ */ jsxs3("div", { className: "cv-entry-top", children: [
                /* @__PURE__ */ jsxs3("div", { children: [
                  /* @__PURE__ */ jsx3("h3", { children: "Diploma in Information Technology" }),
                  /* @__PURE__ */ jsx3("p", { children: "Universiti Teknikal Malaysia Melaka" })
                ] }),
                /* @__PURE__ */ jsx3("span", { children: "2020 \u2013 2023" })
              ] }),
              /* @__PURE__ */ jsx3("div", { className: "cv-academic", children: /* @__PURE__ */ jsx3("strong", { children: "3.42 CGPA" }) })
            ] })
          ] }),
          /* @__PURE__ */ jsxs3("section", { children: [
            /* @__PURE__ */ jsx3(Heading, { id: "projects", children: "Selected projects" }),
            /* @__PURE__ */ jsx3("div", { className: "cv-projects", children: projects.map((project) => /* @__PURE__ */ jsxs3("div", { className: "cv-entry", children: [
              /* @__PURE__ */ jsxs3("div", { className: "cv-entry-top", children: [
                /* @__PURE__ */ jsx3("h3", { children: project.name }),
                /* @__PURE__ */ jsx3("span", { children: project.org })
              ] }),
              /* @__PURE__ */ jsx3("p", { children: project.intro }),
              /* @__PURE__ */ jsx3("ul", { className: "cv-detail", children: project.built.map((item) => /* @__PURE__ */ jsx3("li", { children: item }, item)) }),
              /* @__PURE__ */ jsx3("span", { className: "cv-stack", children: project.tech })
            ] }, project.id)) }),
            /* @__PURE__ */ jsx3("a", { className: "inline-link", href: "project.html", children: "Explore project case studies \u2197" })
          ] }),
          /* @__PURE__ */ jsxs3("section", { children: [
            /* @__PURE__ */ jsx3(Heading, { id: "skills", children: "Technical skills" }),
            /* @__PURE__ */ jsx3("div", { className: "cv-skill-groups", children: skills.map(([group, items]) => /* @__PURE__ */ jsxs3("div", { children: [
              /* @__PURE__ */ jsx3("h3", { children: group }),
              /* @__PURE__ */ jsx3("ul", { children: items.map((item) => /* @__PURE__ */ jsx3("li", { children: item }, item)) })
            ] }, group)) })
          ] }),
          /* @__PURE__ */ jsxs3("section", { children: [
            /* @__PURE__ */ jsx3(Heading, { id: "awards", children: "Awards & training" }),
            /* @__PURE__ */ jsxs3("div", { className: "cv-award", children: [
              /* @__PURE__ */ jsx3("span", { children: "Gold" }),
              /* @__PURE__ */ jsxs3("div", { children: [
                /* @__PURE__ */ jsx3("h3", { children: "Final Year Project Showcase, UniSZA" }),
                /* @__PURE__ */ jsx3("p", { children: "AR MicroLearn" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs3("div", { className: "cv-award", children: [
              /* @__PURE__ */ jsx3("span", { children: "Silver" }),
              /* @__PURE__ */ jsxs3("div", { children: [
                /* @__PURE__ */ jsx3("h3", { children: "Minggu Penyelidikan & Inovasi 2026" }),
                /* @__PURE__ */ jsx3("p", { children: "AR MicroLearn, the same degree final-year project" })
              ] })
            ] }),
            /* @__PURE__ */ jsx3("p", { className: "cv-training", children: "Power BI training / HRD Corp, August 2025" })
          ] }),
          /* @__PURE__ */ jsxs3("div", { className: "cv-end", children: [
            /* @__PURE__ */ jsx3(Icon, {}),
            /* @__PURE__ */ jsx3("span", { children: "Explore more in the portfolio, or take the r\xE9sum\xE9 with you." }),
            /* @__PURE__ */ jsx3("a", { href: pdf, download: true, children: "Download PDF \u2193" })
          ] })
        ] })
      ] })
    ] })
  ] });
}

// scripts/export-static.jsx
import { Fragment as Fragment5, jsx as jsx4, jsxs as jsxs4 } from "react/jsx-runtime";
var pages = { index: [Overview, "Overview"], project: [Projects, "Projects"], certs: [Awards, "Awards & learning"], contact: [Contact, "Contact"], resume: [Resume, "R\xE9sum\xE9"] };
for (const [name, [Page, title]] of Object.entries(pages)) {
  let content = renderToStaticMarkup(/* @__PURE__ */ jsxs4(Fragment5, { children: [
    /* @__PURE__ */ jsx4("a", { className: "skip", href: "#main", children: "Skip to content" }),
    /* @__PURE__ */ jsx4(Header, { page: name }),
    /* @__PURE__ */ jsx4("main", { id: "main", children: /* @__PURE__ */ jsx4(Page, {}) }),
    /* @__PURE__ */ jsx4(Footer, {})
  ] }));
  content = content.replace("grid grid-cols-1 gap-6 min-[701px]:grid-cols-2", "projects").replace("wrap flex flex-wrap items-center justify-between gap-5", "wrap");
  if (name === "resume") content = content.replace("</main>", '<div class="wrap resume-pdf" id="resume-pdf" hidden><p>This is the original PDF. <a href="assets/Imran-Hakim-Resume.pdf" target="_blank" rel="noopener noreferrer">Open it directly</a> if the preview is unavailable.</p><iframe data-src="assets/Imran-Hakim-Resume.pdf#view=FitH" title="Muhammad Imran Hakim original PDF r\xE9sum\xE9"></iframe></div></main>');
  if (name === "project") content += projects.map((project) => renderToStaticMarkup(/* @__PURE__ */ jsxs4("dialog", { id: "case-" + project.id, "aria-labelledby": "title-" + project.id, children: [
    /* @__PURE__ */ jsxs4("div", { className: "dialog-top", children: [
      /* @__PURE__ */ jsx4("span", { children: "Project case study" }),
      /* @__PURE__ */ jsx4("button", { className: "close-case", children: "Close \xD7" })
    ] }),
    /* @__PURE__ */ jsx4("h2", { id: "title-" + project.id, children: project.name }),
    /* @__PURE__ */ jsxs4("p", { className: "tags", children: [
      project.org,
      " / ",
      project.tech
    ] }),
    /* @__PURE__ */ jsx4("p", { children: project.intro }),
    /* @__PURE__ */ jsx4("h3", { children: "The challenge" }),
    /* @__PURE__ */ jsx4("p", { children: project.challenge }),
    /* @__PURE__ */ jsx4("h3", { children: "What I built" }),
    /* @__PURE__ */ jsx4("ul", { children: project.built.map((item) => /* @__PURE__ */ jsx4("li", { children: item }, item)) }),
    /* @__PURE__ */ jsx4("h3", { children: "The result" }),
    /* @__PURE__ */ jsx4("p", { children: project.result })
  ] }))).join("");
  writeFileSync(name + ".html", '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<meta name="description" content="Muhammad Imran Hakim: IT support, infrastructure and application development portfolio.">\n<title>' + title + ' | Imran Hakim</title>\n<link rel="stylesheet" href="styles.css">\n<script src="app.js" defer></script>\n</head>\n<body>\n' + content.replace(/></g, ">\n<") + "\n</body>\n</html>\n");
}
var css = readFileSync("frontend/src/styles.css", "utf8").replace(/^@import "tailwindcss";\s*/, "").replace(/^@source .*?;\s*/m, "");
css += "\n[hidden]{display:none!important}.close-case{border:0;background:transparent;padding:8px}#resume-pdf{margin-bottom:80px}.resume-sidebar nav{min-height:0}\n";
writeFileSync("styles.css", css);
console.log("Exported five standalone HTML pages and plain CSS.");
