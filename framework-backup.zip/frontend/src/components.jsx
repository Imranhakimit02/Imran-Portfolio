import { Fragment, useEffect, useRef, useState } from 'react';
import { projects, weeks } from './data.js';

export function Journal() {
  return <div id="journal">{weeks.map(([date, title, text], index) =>
    <details key={title}>
      <summary><small>Week {index + 1} / {date}</small><strong>{title}</strong></summary>
      <p>{text}</p>
    </details>
  )}</div>;
}

export function CopyEmail() {
  const [status, setStatus] = useState('');
  async function copy() {
    try {
      await navigator.clipboard.writeText('imranhakimit02@gmail.com');
      setStatus('Email copied.');
    } catch {
      setStatus('Please copy: imranhakimit02@gmail.com');
    }
  }
  return <><button id="copy" onClick={copy}>Copy email address</button><span id="status" role="status">{status}</span></>;
}

function CaseStudy({ project, onClose }) {
  const dialog = useRef(null);
  useEffect(() => {
    const node = dialog.current;
    node.showModal();
    return () => node.close();
  }, []);
  function dismissBackdrop(event) {
    if (event.target !== dialog.current) return;
    const box = dialog.current.getBoundingClientRect();
    if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) onClose();
  }
  return <dialog ref={dialog} id="case" aria-labelledby="case-title" onCancel={event => { event.preventDefault(); onClose(); }} onClick={dismissBackdrop}>
    <div className="dialog-top"><span>Project case study</span><button id="close" onClick={onClose}>Close <span aria-hidden="true">×</span></button></div>
    <h2 id="case-title">{project.name}</h2>
    <p className="tags">{project.org} / {project.tech}</p>
    <p>{project.intro}</p>
    <h3>The challenge</h3><p>{project.challenge}</p>
    <h3>What I built</h3><ul>{project.built.map(item => <li key={item}>{item}</li>)}</ul>
    <h3>The result</h3><p>{project.result}</p>
  </dialog>;
}

export function ProjectGallery() {
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState(null);
  const trigger = useRef(null);
  function close() {
    setSelected(null);
    trigger.current?.focus();
  }
  const filters = [['all', 'All projects'], ['enterprise', 'Enterprise applications'], ['academic', 'Academic projects']];
  return <>
    <div className="filters" role="group" aria-label="Filter projects">
      {filters.map(([value, label]) => <button key={value} data-filter={value} aria-pressed={filter === value} onClick={() => setFilter(value)}>{label}</button>)}
    </div>
    <div id="projects" className="grid grid-cols-1 gap-6 min-[701px]:grid-cols-2">
      {projects.filter(project => filter === 'all' || project.category === filter).map(project =>
        <article key={project.id} className="project" data-category={project.category}>
          {project.steps && <div className={'art ' + project.id} aria-hidden="true">
            <span className="art-title">{project.name}</span>
            <div className="route">{project.steps.map((step, index) => <Fragment key={step}>{index > 0 && '→'}<span>{step}</span></Fragment>)}</div>
            <span className="art-foot">{project.caption}</span>
          </div>}
          <div className="body">
            <div className="meta"><span>{project.org}</span><span>0{projects.indexOf(project) + 1} / {project.category === 'enterprise' ? 'Enterprise' : 'Academic'}</span></div>
            <h3>{project.name}</h3><p>{project.intro}</p>
            <div className="project-bottom"><span>{project.tech}</span><button className="open" data-project={project.id} aria-label={'Read ' + project.name + ' case study'} onClick={event => { trigger.current = event.currentTarget; setSelected(project); }}>View case study ↗</button></div>
          </div>
        </article>
      )}
    </div>
    {selected && <CaseStudy project={selected} onClose={close} />}
  </>;
}

export function Header({ page }) {
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(() => {
    try { return localStorage.getItem('portfolio-theme') === 'dark'; } catch { return false; }
  });
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    try { localStorage.setItem('portfolio-theme', dark ? 'dark' : 'light'); } catch { /* Storage may be disabled. */ }
  }, [dark]);
  useEffect(() => {
    function escape(event) { if (event.key === 'Escape') setOpen(false); }
    document.addEventListener('keydown', escape);
    return () => document.removeEventListener('keydown', escape);
  }, []);
  const links = [['index', 'Overview'], ['project', 'Projects'], ['certs', 'Awards & learning'], ['resume', 'Résumé'], ['contact', 'Contact']];
  return <header><nav className="wrap" aria-label="Main navigation">
    <a className="brand" href="index.html" aria-label="Imran Hakim home">IH<span className="brand-name">Imran Hakim</span></a>
    <button id="menu" aria-expanded={open} aria-controls="links" onClick={() => setOpen(value => !value)}>Menu</button>
    <div id="links" className={open ? 'is-open' : ''}>
      {links.map(([id, label]) => <a key={id} href={id + '.html'} aria-current={id === page ? 'page' : undefined} onClick={() => setOpen(false)}>{label}</a>)}
      <button id="theme-toggle" aria-label="Switch colour theme" aria-pressed={dark} onClick={() => setDark(value => !value)}>{dark ? 'Light mode' : 'Dark mode'}</button>
      <a className="resume" href="assets/Imran-Hakim-Resume.pdf" download>Resume PDF <span aria-hidden="true">↓</span></a>
    </div>
  </nav></header>;
}

export function Footer() {
  return <footer className="wrap flex flex-wrap items-center justify-between gap-5">
    <span>© 2026 Imran Hakim / Malaysia</span><a href="contact.html">Let's connect</a><a href="#main">Back to top ↑</a>
  </footer>;
}
