import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Header, Footer } from './components.jsx';
import { Overview, Projects, Awards, Contact } from './Pages.jsx';
import { Resume } from './Resume.jsx';
import './styles.css';

const pages = { index: Overview, project: Projects, certs: Awards, resume: Resume, contact: Contact };
const page = location.pathname.split('/').pop().replace(/\.html$/, '') || 'index';
const Page = pages[page] || Overview;
document.documentElement.classList.add('js');

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <a className="skip" href="#main">Skip to content</a>
    <Header page={page} />
    <main id="main"><Page /></main>
    <Footer />
  </StrictMode>
);
