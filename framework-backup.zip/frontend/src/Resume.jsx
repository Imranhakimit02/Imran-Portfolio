import { useState } from 'react';
import { projects } from './data.js';

const pdf = 'assets/Imran-Hakim-Resume.pdf';
const sections = [['profile', 'Profile'], ['experience', 'Experience'], ['education', 'Education'], ['projects', 'Projects'], ['skills', 'Skills'], ['awards', 'Awards']];
const skills = [
  ['IT support', ['Windows 10/11 imaging', 'Hardware & software troubleshooting', 'Microsoft 365', 'User access support', 'Endpoint provisioning', 'BIOS / boot configuration', 'Driver installation']],
  ['Networking', ['Structured cabling', 'RJ45 termination', 'Patch panels', 'Network racks', 'Cable testing & tracing', 'Network troubleshooting']],
  ['Development', ['PHP', 'MySQL / SQL', 'HTML / CSS', 'C# / .NET', 'Relational database design', 'RBAC', 'System testing', 'Vuforia AR', 'Visual Studio 2022']],
  ['Data', ['Microsoft Power BI', 'DAX', 'Data modeling', 'Interactive dashboards']],
];

function Icon({ type = 'document' }) {
  const paths = {
    document: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h6"/></>,
    work: <><rect x="3" y="7" width="18" height="14" rx="1"/><path d="M8 7V3h8v4M3 12h18M10 12v3h4v-3"/></>,
    education: <><path d="m2 9 10-6 10 6-10 6zM6 12v6c4 3 8 3 12 0v-6M22 9v8"/></>,
    projects: <><path d="m8 5-7 7 7 7M16 5l7 7-7 7M14 3l-4 18"/></>,
    skills: <><path d="m12 2 9 5v10l-9 5-9-5V7zM3 7l9 5 9-5M12 12v10"/></>,
    awards: <><circle cx="12" cy="8" r="6"/><path d="m8 13-2 9 6-3 6 3-2-9"/></>,
  };
  return <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[type] || paths.document}</svg>;
}

function Heading({ id, children, icon }) {
  return <h2 id={'resume-' + id} className="cv-heading"><Icon type={icon || id} />{children}</h2>;
}

export function Resume() {
  const [view, setView] = useState('web');
  const [compact, setCompact] = useState(false);
  return <>
    <section className="wrap resume-intro">
      <div><span className="page-index">Résumé / A closer look</span><h1>Experience,<br />at a glance.</h1><p>The people I support. The systems I build. The skills behind both.</p></div>
      <a className="button" href={pdf} download><Icon />Download PDF <span aria-hidden="true">↓</span></a>
    </section>
    <section className="wrap resume-workspace" aria-label="Interactive résumé">
      <div className="resume-toolbar">
        <div className="resume-views" role="group" aria-label="Résumé format">
          <button aria-pressed={view === 'web'} onClick={() => setView('web')}>Interactive résumé</button>
          <button aria-pressed={view === 'pdf'} onClick={() => setView('pdf')}>Original PDF</button>
        </div>
        {view === 'web' ? <button className="resume-density" aria-pressed={compact} onClick={() => setCompact(value => !value)}>{compact ? 'Show full details' : 'Show highlights'}</button> : <a className="resume-density" href={pdf} target="_blank" rel="noopener noreferrer">Open PDF in new tab ↗</a>}
      </div>
      {view === 'pdf' ? <div className="resume-pdf"><p>This is the original PDF. <a href={pdf} target="_blank" rel="noopener noreferrer">Open it directly</a> if the preview is unavailable.</p><iframe src={pdf + '#view=FitH'} title="Muhammad Imran Hakim original PDF résumé" /></div> :
        <div className="resume-layout">
          <aside className="resume-sidebar"><span className="resume-sidebar-label">On this résumé</span><nav aria-label="Résumé sections">{sections.map(([id, name]) => <a key={id} href={'#resume-' + id}>{name}<span aria-hidden="true">↗</span></a>)}</nav><div className="resume-sidebar-note"><Icon /><p>Prefer a document?<br /><a href={pdf} download>Keep a PDF copy ↓</a></p></div></aside>
          <article className={'resume-sheet' + (compact ? ' is-compact' : '')} aria-label="Muhammad Imran Hakim résumé">
            <div className="cv-masthead"><div className="cv-logo" aria-hidden="true">ih<span>.</span></div><div><h2>Muhammad Imran Hakim<span>bin Abd Rashid</span></h2><p>IT support / Infrastructure / Application development</p></div></div>
            <div className="cv-contact"><span>Kota Bharu, Kelantan, Malaysia</span><a href="mailto:imranhakimit02@gmail.com">imranhakimit02@gmail.com</a><a href="tel:+601119809130">+60 11-1980 9130</a><a href="https://www.linkedin.com/in/imran-hakim-0b195a366/" target="_blank" rel="noopener noreferrer">LinkedIn ↗</a></div>
            <section><Heading id="profile" icon="document">Professional profile</Heading><p>Final-year Bachelor of Information Technology (Informatics Media) student with a 3.68 CGPA and hands-on enterprise experience in IT infrastructure, technical support, and full-stack web development. Experienced in structured network cabling, endpoint provisioning, Windows deployment, troubleshooting, PHP/MySQL development, and relational database design.</p><p className="cv-detail">Developed internal business applications at Leader Energy, including a cross-departmental ticketing and workflow system and a project monitoring system. Interested in building a career in IT infrastructure, systems, or application support.</p></section>
            <section><Heading id="experience" icon="work">Work experience</Heading><div className="cv-entry"><div className="cv-entry-top"><div><h3>IT Support Intern</h3><p>Leader Energy Group Berhad / George Town</p></div><span>Aug 2026 – Mar 2027<br /><small>Expected completion</small></span></div><p className="cv-highlight">Built two internal PHP/MySQL applications, alongside hands-on enterprise IT support.</p><ul className="cv-detail"><li>Built and deployed a nine-department project monitoring system and a ticketing system centralizing HR and Finance requests.</li><li>Prepared corporate endpoints through Windows 10/11 reimaging, BIOS/boot configuration, driver installation, and software setup.</li><li>Resolved hardware, software, and access issues for internal users.</li><li>Established and verified server-room network connections through RJ45 termination, patch-panel installation, cable testing, and tracing.</li></ul></div><div className="cv-entry"><div className="cv-entry-top"><div><h3>IT Assistant Intern</h3><p>Universiti Teknikal Malaysia Melaka / Melaka</p></div><span>Jun – Aug 2022</span></div><p className="cv-highlight">Improved learning-system usability and tested data and application reliability.</p><ul className="cv-detail"><li>Implemented U-CREDs interface improvements supporting access to learning resources for 300+ students and faculty.</li><li>Identified defects and data inconsistencies through system testing and audits covering 100+ production assets.</li></ul></div></section>
            <section><Heading id="education">Education</Heading><div className="cv-entry"><div className="cv-entry-top"><div><h3>Bachelor of Information Technology</h3><p>Informatics Media / Universiti Sultan Zainal Abidin</p></div><span>2023 – 2027<br /><small>Expected graduation</small></span></div><div className="cv-academic"><strong>3.68 CGPA</strong><span>Dean’s List: semesters 1, 3, 4, 5, 6</span></div></div><div className="cv-entry"><div className="cv-entry-top"><div><h3>Diploma in Information Technology</h3><p>Universiti Teknikal Malaysia Melaka</p></div><span>2020 – 2023</span></div><div className="cv-academic"><strong>3.42 CGPA</strong></div></div></section>
            <section><Heading id="projects">Selected projects</Heading><div className="cv-projects">{projects.map(project => <div className="cv-entry" key={project.id}><div className="cv-entry-top"><h3>{project.name}</h3><span>{project.org}</span></div><p>{project.intro}</p><ul className="cv-detail">{project.built.map(item => <li key={item}>{item}</li>)}</ul><span className="cv-stack">{project.tech}</span></div>)}</div><a className="inline-link" href="project.html">Explore project case studies ↗</a></section>
            <section><Heading id="skills">Technical skills</Heading><div className="cv-skill-groups">{skills.map(([group, items]) => <div key={group}><h3>{group}</h3><ul>{items.map(item => <li key={item}>{item}</li>)}</ul></div>)}</div></section>
            <section><Heading id="awards">Awards & training</Heading><div className="cv-award"><span>Gold</span><div><h3>Final Year Project Showcase, UniSZA</h3><p>AR MicroLearn</p></div></div><div className="cv-award"><span>Silver</span><div><h3>Minggu Penyelidikan & Inovasi 2026</h3><p>AR MicroLearn, the same degree final-year project</p></div></div><p className="cv-training">Power BI training / HRD Corp, August 2025</p></section>
            <div className="cv-end"><Icon /><span>Explore more in the portfolio, or take the résumé with you.</span><a href={pdf} download>Download PDF ↓</a></div>
          </article>
        </div>}
    </section>
  </>;
}
